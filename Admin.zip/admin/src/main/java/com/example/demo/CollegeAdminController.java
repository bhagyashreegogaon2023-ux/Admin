package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/collegeadmin")
public class CollegeAdminController {

    @Autowired
    private CollegeAdminService service;

    @PostMapping
    public CollegeAdmin saveAdmin(@RequestBody CollegeAdmin admin) {
        return service.saveAdmin(admin);
    }

    @GetMapping
    public List<CollegeAdmin> getAllAdmins() {
        return service.getAllAdmins();
    }

    @GetMapping("/{id}")
    public CollegeAdmin getAdminById(@PathVariable Long id) {
        return service.getAdminById(id);
    }
}