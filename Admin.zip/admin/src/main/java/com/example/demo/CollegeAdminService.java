package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollegeAdminService {

    @Autowired
    private CollegeAdminRepository repository;

    public CollegeAdmin saveAdmin(CollegeAdmin admin) {
        return repository.save(admin);
    }

    public List<CollegeAdmin> getAllAdmins() {
        return repository.findAll();
    }

    public CollegeAdmin getAdminById(Long id) {
        return repository.findById(id).orElse(null);
    }
}